/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'ms', {
	alt: 'Text Alternatif',
	btnUpload: 'Hantar ke Server',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Info Imej',
	lockRatio: 'Tetapkan Nisbah',
	menu: 'Ciri-ciri Imej',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Saiz Set Semula',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Ciri-ciri Imej',
	uploadTab: 'Muat Naik',
	urlMissing: 'Image source URL is missing.', // MISSING
	altMissing: 'Alternative text is missing.' // MISSING
} );
